function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createElementVNode("header", null, [
      _hoisted_1,
      _hoisted_2,
      _createElementVNode("div", _hoisted_3, [
        _createVNode($setup["HelloWorld"], { msg: "You did it!" })
      ])
    ]),
    _createElementVNode("main", null, [
      _createVNode($setup["TheWelcome"])
    ])
  ], 64 /* STABLE_FRAGMENT */))
}