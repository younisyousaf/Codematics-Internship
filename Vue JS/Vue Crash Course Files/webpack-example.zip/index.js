import "./style.scss"
  
document.querySelector("#app").innerHTML = `
  <h1>Hello Webpack!</h1>
  <a href="https://webpack.js.org/concepts/" target="_blank">Documentation</a>
`